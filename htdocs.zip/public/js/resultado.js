setTimeout(() => {
    window.location.href = "/jugarPartida/redirect";
}, 5000);